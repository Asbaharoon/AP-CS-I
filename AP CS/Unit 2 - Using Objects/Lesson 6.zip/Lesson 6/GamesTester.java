public class GamesTester
{
    public static void main(String[] args)
    {
        NumberGames game = new NumberGames(3);
        
        // Double the number
        // Print it out
        
        
        // Square the number
        // Print it out
        
        // Double the number again
        // Print it out
        
        // Get the number and store the value
        // Print it out to see that getNumber does
        // not modify the number

    }
}
