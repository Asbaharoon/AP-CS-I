package Activity3;

public class Celebrity
{
    //Copy over your code from the previous exercise for the Celebrity class
}
