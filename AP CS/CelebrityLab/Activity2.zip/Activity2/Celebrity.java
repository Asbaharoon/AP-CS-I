package Activity2;

public class Celebrity {
    
}
