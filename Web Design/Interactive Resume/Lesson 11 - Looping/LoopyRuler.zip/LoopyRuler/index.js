function setup() {
    createCanvas(400, 400);
}

function draw() {
    fill(17, 0, 255);

    // a handy dandy ruler across the top
    var x = 0;
    text(x, x, 10);
    text(x + 50, x + 50, 10);
    text(x + 100, x + 100, 10);
    text(x + 150, x + 150, 10);
    text(x + 200, x + 200, 10);
    text(x + 250, x + 250, 10);
    text(x + 300, x + 300, 10);
    text(x + 350, x + 350, 10);

};