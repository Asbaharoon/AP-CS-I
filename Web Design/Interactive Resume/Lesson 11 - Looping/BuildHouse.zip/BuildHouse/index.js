function setup() {
    createCanvas(400, 400);
}

function draw() {
    background(219, 255, 255);

    fill(174, 180, 214);
    triangle(200, 28, 350, 150, 50, 150);

    fill(255, 255, 255);
    rect(60, 150, 280, 207);

    fill(120, 80, 19);
    rect(180, 280, 40, 77);
};