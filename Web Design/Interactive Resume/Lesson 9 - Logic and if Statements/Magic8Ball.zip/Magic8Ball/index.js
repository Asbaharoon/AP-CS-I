function setup() {
    createCanvas(400, 400);
}

function draw() {
    fill(0, 0, 0);
    ellipse(200, 200, 375, 375);
    fill(60, 0, 255);
    triangle(200, 104, 280, 280, 120, 280);
    fill(255, 255, 255);
    var answer = floor(random(1, 5));
    if (answer > 0) {
        text("YOUR", 176, 200);
        text("MESSAGE", 159, 229);
    }
};