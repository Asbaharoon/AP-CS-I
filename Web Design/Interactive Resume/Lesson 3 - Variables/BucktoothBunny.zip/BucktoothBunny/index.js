function setup() {
    createCanvas(400, 400);
}

function draw() {
    background(220);

    ellipse(150, 70, 60, 120); // left ear
    ellipse(240, 70, 60, 120); // right ear

    ellipse(200, 170, 150, 150); // face

    fill(0, 0, 0);
    ellipse(170, 150, 10, 10); // left eye
    ellipse(230, 150, 10, 10); // right eye

    line(150, 200, 250, 200); // mouth

    noFill();
    rect(185, 200, 15, 10); // left tooth
    rect(200, 200, 15, 10); // right tooth
}