function setup() {
    createCanvas(400, 400);
}

function draw() {
    background(186, 145, 20); // wooden table
    ellipse(200, 200, 350, 350); // plate
    ellipse(200, 200, 300, 300);

}