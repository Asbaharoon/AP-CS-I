function setup() {
    createCanvas(400, 400);
}

var xPos = 200;
var yPos = 200;

function draw() {

    background(29, 40, 115);
    fill(255, 242, 0);
    ellipse(xPos, yPos, 10, 10);
}