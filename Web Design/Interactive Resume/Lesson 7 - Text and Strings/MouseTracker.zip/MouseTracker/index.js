function setup() {
    createCanvas(400, 400);
}

function draw() {
    fill(255, 0, 255);
    background(255, 255, 255);
    ellipse(36, 45, 12, 12);
}