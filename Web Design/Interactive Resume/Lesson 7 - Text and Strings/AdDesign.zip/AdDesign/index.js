function setup() {
    createCanvas(400, 400);
}

function draw() {
    fill(255, 0, 0);
    textSize(30);
    text("STUFFED WINSTON!", 10, 30);
}